# Chess_game_javascript
Building a chess game using HTML5, CSS and JavaScript only.(No jQuery)
